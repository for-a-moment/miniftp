#ifndef _PRIVPARENT_H_
#define _PRIVPARENT_H_

#include"common.h"
#include"session.h"

void handle_parent(session_t *sess);

#endif